
'use client';
import { useState } from 'react';

export default function Home() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    if (!input) return;
    setMessages([...messages, { role: 'user', content: input }]);
    setLoading(true);
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: input }),
    });
    const data = await res.json();
    setMessages([...messages, { role: 'user', content: input }, { role: 'assistant', content: data.reply }]);
    setInput('');
    setLoading(false);
  };

  return (
    <main className="p-4 min-h-screen bg-black text-white">
      <h1 className="text-3xl font-bold mb-4 text-gold">Alpha AI</h1>
      <div className="space-y-2 mb-4">
        {messages.map((msg, i) => (
          <div key={i} className={msg.role === 'user' ? 'text-right' : 'text-left'}>
            <span className="block p-2 bg-gray-800 rounded-md inline-block">{msg.content}</span>
          </div>
        ))}
        {loading && <p className="text-gray-400">Thinking...</p>}
      </div>
      <div className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="flex-grow p-2 bg-gray-900 border border-gray-700 rounded"
          placeholder="Ask something..."
        />
        <button onClick={sendMessage} className="bg-gold text-black px-4 py-2 rounded">Send</button>
      </div>
    </main>
  );
}
