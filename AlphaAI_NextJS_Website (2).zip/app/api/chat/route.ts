
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  const { message } = await req.json();

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer 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`,
    },
    body: JSON.stringify({
      model: 'gpt-4',
      messages: [{ role: 'user', content: message }],
    }),
  });

  const data = await response.json();
  const reply = data.choices?.[0]?.message?.content || 'Sorry, no response.';

  return NextResponse.json({ reply });
}
